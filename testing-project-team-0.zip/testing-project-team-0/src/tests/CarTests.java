package tests;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.BeforeAll;

import car.Car;

/**
 * Contains the test cases that will reveal the errors in the car class.
 * 
 * @author Dario,Danish,Liz
 */

public class CarTests {
	private static final double ERROR_TOLERANCE = 0.001;

	private Car car;
	private Car otherCar;

	@BeforeEach
	void setUp() {
		// Car having default values of 20 MPG and 10 gallons.
		car = new Car();
		otherCar = new Car();

	}

	/**
	 * Checks if the constructors return the correct values. Tests to see if default
	 * values are given incase no values entered in constructor. Car is in park
	 * gear, with a full tank and at location 0.0.
	 */
	@Test
	public void test_Constructor() {
		assertEquals(20.0, car.getMPG(), ERROR_TOLERANCE);
		assertEquals(10.0, car.getCapacity(), ERROR_TOLERANCE);
		assertEquals(0.0, car.getLocation(), ERROR_TOLERANCE);
		assertEquals(10.0, car.getRemainingGas(), ERROR_TOLERANCE);
		assertEquals(Car.PARK, car.getGear());
	}

	/**
	 * Tests the expected toString output with the actual toString output
	 */
	@Test
	public void test_toString() {

		String expected = "Tank Capacity: 10.0\nMPG: 20.0\nGas left: 10.0\nGear: Park\nLocation: 0.0";
		assertEquals(expected, car.toString());

		car.setGear(Car.FORWARD);
		car.go(100);

		expected = "Tank Capacity: 10.0\nMPG: 20.0\nGas left: 5.0\nGear: Forward\nLocation: 100.0";
		assertEquals(expected, car.toString());

		car.setGear(Car.REVERSE);
		car.go(100);

		expected = "Tank Capacity: 10.0\nMPG: 20.0\nGas left: 0.0\nGear: Reverse\nLocation: 0.0";
		assertEquals(expected, car.toString());

	}

	/**
	 * Tests for comparison based on location of the cars
	 */
	@Test
	public void test_CompareTo() {
		assertEquals(0, car.compareTo(otherCar));
		assertEquals(0, otherCar.compareTo(car));

		car.setGear(Car.FORWARD);
		otherCar.setGear(Car.FORWARD);
		car.go(10);
		otherCar.go(15);

		assertEquals(-1, car.compareTo(otherCar));
		assertEquals(1, otherCar.compareTo(car));

		// Both at same location now as otherCar goes in reverse for 5 miles
		otherCar.setGear(Car.REVERSE);
		otherCar.go(5);
		assertEquals(0, car.compareTo(otherCar));
		assertEquals(0, otherCar.compareTo(car));

		// car2 which travels the same distance in the same direction as car
		Car car2 = new Car();
		car2.setGear(Car.FORWARD);
		car2.go(10);
		assertEquals(0, car.compareTo(car2));
		assertEquals(0, car2.compareTo(car));

		// Both travel same distance but in opposite directions.
		car.setGear(Car.REVERSE);
		otherCar.setGear(Car.FORWARD);
		car.go(10);
		otherCar.go(10);
		assertEquals(-1, car.compareTo(otherCar));
		assertEquals(1, otherCar.compareTo(car));

		/**
		 * Cars moving in Park gear, should give 0 as Car cant move in parking gear so
		 * // both cars still at same distance. car2.setGear(Car.PARK);
		 * car.setGear(Car.PARK); car2.go(20); assertEquals(0, car2.compareTo(car2));
		 * assertEquals(0, car.compareTo(car2));
		 */

	}

	/**
	 * Tests the value input for gear
	 */
	@Test
	public void test_SetGear_NormalCase() {
		assertEquals(Car.PARK, car.getGear());

		car.setGear(Car.PARK);
		assertEquals(Car.PARK, car.getGear());

		car.setGear(Car.FORWARD);
		assertEquals(Car.FORWARD, car.getGear());

		car.setGear(Car.REVERSE);
		assertEquals(Car.REVERSE, car.getGear());

	}

	/**
	 * Tests getGear returns the current gear being set
	 */
	@Test
	public void test_getGear() {

		// for forward gear
		car.setGear(Car.FORWARD);
		// forward is 1 so should return true
		assertEquals(Car.FORWARD, car.getGear());

		// for reverse gear
		car.setGear(Car.REVERSE);
		// forward is 2 so should return true
		assertEquals(Car.REVERSE, car.getGear());

		// for park gear
		car.setGear(Car.PARK);
		// park is 0 so should return true
		assertEquals(Car.PARK, car.getGear());

	}

	/**
	 * Tests illegal arguments for setGear
	 */
	@Test
	public void test_SetGear_ThrowsExceptions() {
		assertThrows(IllegalArgumentException.class, () -> {
			car.setGear(3);
		});
		assertThrows(IllegalArgumentException.class, () -> {
			car.setGear(-1);
		});

	}

	/**
	 * Tests if tank fills up to full capacity
	 */
	@Test
	public void test_FillTank() {
		// Starting off with a full tank
		assertEquals(10.0, car.getRemainingGas(), ERROR_TOLERANCE);
		assertEquals(car.getCapacity(), car.getRemainingGas(), ERROR_TOLERANCE);

		car.setGear(Car.FORWARD);
		car.go(100);
		car.setGear(Car.PARK);
		car.fillTank();
		assertEquals(car.getCapacity(), car.getRemainingGas(), ERROR_TOLERANCE);

		car.setGear(Car.REVERSE);
		car.go(200);
		car.setGear(Car.PARK);
		car.fillTank();
		assertEquals(car.getCapacity(), car.getRemainingGas(), ERROR_TOLERANCE);

	}

	@Test
	public void test_FillTank_ThrowsException() {

		// Tank is already full so can't fill more
		car.setGear(Car.PARK);
		assertThrows(IllegalStateException.class, () -> {
			car.fillTank();
		});

		car.setGear(Car.FORWARD);
		car.go(100);
		car.setGear(Car.PARK);
		car.fillTank();
		assertThrows(IllegalStateException.class, () -> {
			car.fillTank();
		});

		// Cannot fill tank while in a different gear than park
		car.setGear(Car.FORWARD);
		car.go(100);
		assertThrows(IllegalStateException.class, () -> {
			car.fillTank();
		});

		car.setGear(Car.REVERSE);
		car.go(15);
		assertThrows(IllegalStateException.class, () -> {
			car.fillTank();
		});

	}

	@Test
	public void test_GetCapacity() {
		assertEquals(10.0, car.getCapacity(), ERROR_TOLERANCE);
	}

	/**
	 * Tests getLocation returns the current gear being set or moving
	 */
	@Test
	public void test_getLocation() {

		// assuming starting position is at 0
		assertEquals(0.0, car.getLocation(), ERROR_TOLERANCE);

		car.setGear(Car.FORWARD);
		car.go(10);

		// check if position returned correctly changes
		assertEquals(10.0, car.getLocation(), ERROR_TOLERANCE);

		car.setGear(Car.REVERSE);
		car.go(20);

		// Checking for negative location
		// Car goes in reverse for 20 miles, so 20 should be subtracted from current
		// location which is 10
		assertEquals(-10.0, car.getLocation(), ERROR_TOLERANCE);

		// Makes sure car can not go further than its gas capacity allows it. Car has
		// already travelled for 30 miles. Current location
		// is -10.0, so it can only travel upto 170 miles before it empties fuel tank.
		car.setGear(Car.FORWARD);
		car.go(200);

		assertEquals(160.0, car.getLocation(), ERROR_TOLERANCE);

		// Car back at location 0.0
		car.setGear(Car.PARK);
		car.fillTank();
		car.setGear(Car.REVERSE);
		car.go(160);

		assertEquals(0.0, car.getLocation(), ERROR_TOLERANCE);

		// Location consistent with go and fuel in tank
		car.setGear(Car.PARK);
		car.fillTank();
		car.setGear(Car.FORWARD);
		car.go(220);

		assertEquals(200.0, car.getLocation(), ERROR_TOLERANCE);

	}

	/**
	 * Tests getMPG returns the current set MPG
	 */
	@Test
	public void test_getMPG() {

		// given default 20 MPG
		assertEquals(20.0, car.getMPG(), ERROR_TOLERANCE);
	}

	/**
	 * Tests getRemainingGas returns the current set Gas
	 */
	@Test
	public void test_getRemainingGas() {

		// given default 10 gas
		assertEquals(10.0, car.getRemainingGas(), ERROR_TOLERANCE);

		car.setGear(Car.FORWARD);
		car.go(100);

		// test if remaining gas decreases after moving
		assertEquals(5.0, car.getRemainingGas(), ERROR_TOLERANCE);

		// Travelled total of 200 miles so remaining gas should be 0.
		car.setGear(Car.REVERSE);
		car.go(100);

		assertEquals(0.0, car.getRemainingGas(), ERROR_TOLERANCE);

		// Going more than its capacity
		car.setGear(Car.PARK);
		car.fillTank();
		car.setGear(Car.FORWARD);
		car.go(205);
		assertEquals(0.0, car.getRemainingGas(), ERROR_TOLERANCE);
	}

	@Test
	public void test_Go_ThrowsExceptions() {
		// Default gear is PARK, should throw an exception
		assertThrows(IllegalStateException.class, () -> {
			car.go(50);
		});

		// Car can not go while in parking gear
		car.setGear(Car.PARK);
		assertThrows(IllegalStateException.class, () -> {
			car.go(100);
		});

		// Cannot take negative values as input for go
		car.setGear(Car.FORWARD);
		assertThrows(IllegalArgumentException.class, () -> {
			car.go(-100);
		});

		car.setGear(Car.REVERSE);
		assertThrows(IllegalArgumentException.class, () -> {
			car.go(-50);
		});

		// Car will not have fuel so will not be in the correct state to 'go'
		car.setGear(Car.FORWARD);
		car.go(250);
		assertThrows(IllegalStateException.class, () -> {
			car.go(10);
		});

		// Remaining fuel zero after going 200 miles
		car.setGear(Car.PARK);
		car.fillTank();
		car.setGear(Car.REVERSE);
		car.go(200);
		assertThrows(IllegalStateException.class, () -> {
			car.go(50);
		});
	}

}
